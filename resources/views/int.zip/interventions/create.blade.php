@extends('layouts.newapp')
@section('styles')
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style type="text/css">
        input[type="date"],
        input[type="text"] {
            padding: .25rem .5rem;
            border-radius: .5rem;
        }

        input[type="color"] {
            padding: 0;
        }

        .form-group .form-control {
            border-radius: .5rem;
            height: 30px;
        }

        .form-section {
            border-right: 1px solid #ccc;
        }

        .form-section:last-child {
            border-right: none;
            padding-right: 0;
            margin-right: 0;
        }

        .form-section-title {
            margin-bottom: 10px;
            color: #282e3f
        }
        .hidden { display: none; }
    </style>
@endsection


@section('content')

    <!-- Breadcromb Row Start -->
    <div class="row">
        <div class="col-md-12">
            <div class="breadcromb-area">
                <div class="row align-items-center">
                    <div class="col-md-7">
                        <div class="seipkon-breadcromb-left">
                            <h3 style="margin-bottom: 0;row-span: 2">Ajouter une intervention</h3>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="btn-group" role="group" aria-label="Basic example" id="btn_group">
                            <button type="button" class="btn btn-info " onclick="saveintervention()">
                                <i class="fa fa-check"></i> Enregistrer l'intervention
                            </button>
                            <a href="{{ route('interventions.index') }}">
                                <button type="button" class="btn btn-warning btn_retour" style=" margin-left: 120px;">
                                    <i class="fa-solid fa-backward" style="margin-right: 5px"></i>Retour
                                </button>
                            </a>
                            <a href="{{ route('plannings.gear2') }}" class="ml-3">
                                <button type="button" class="btn btn-primary">
                                    <i class="fa fa-gear"></i> Planning
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcromb Row -->

    <!-- Form Layout Row Start -->
    <div class="row">
        <div class="col-md-12">
            <div class="page-box">
                <div class="form-example">
                    <div class="form-wrap top-label-exapmple form-layout-page">
                        <form>
                            <!-- Section rendez-vous moved before the contrat section -->
                            <div class="row date-inputs">
                                <div class="col-md-4 form-section">
                                    <h4 class="form-section-title">Section rendez-vous</h4>
                                    <div class="form-group">
                                        <label class="control-label">Choisir le client: <span class="obligatoire">*</span></label>
                                        <select class="form-control select2" id="client_id" name="client_id" onchange="populateContractSelect(this.value)">
                                            <option value="">Selectionner un client</option>
                                            @foreach ($clients as $client)
                                                <option value="{{ $client->id }}">{{ $client->nom }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Choisir l'entreprise: <span class="obligatoire">*</span></label>
                                        <select class="form-control" id="entreprise_id" name="entreprise_id">
                                            @foreach ($entreprises as $entreprise)
                                                <option value="{{ $entreprise->id }}">{{ $entreprise->nom }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Adresse: <span class="obligatoire">*</span></label>
                                        <input class="form-control" id="address" name="address" type="text" placeholder="{{ $client->adresse }}">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Intervenants: <span class="obligatoire">*</span></label>
                                        <select class="form-control select2" name="intervenant_ids[]" id="intervenant_ids" multiple>
                                            @foreach ($intervenants as $intervenant)
                                                <option value="{{ $intervenant->id }}">{{ $intervenant->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Type: <span class="obligatoire">*</span></label>
                                        <select class="form-control"  id="divSelector" onchange="toggleDivs()">
                                            <option value="">Select a Div</option>
                                            <option value="div1">Contrat</option>
                                            <option value="div2">Planning</option>
                                        </select>
                                    </div>

                                </div>

                                <!-- Section contrat moved after the rendez-vous section -->
                                <div class="col-md-4 form-section hidden" id="div1">
                                    <h4 class="form-section-title">Section contrat</h4>
                                    <div class="form-group">
                                        <label class="control-label">Contrat: </label>
                                        <select class="form-control select2" name="contrat_id" id="contrat_id" onchange="populateContractDates(this.value)">
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Début de contrat: </label>
                                        <input type="date" placeholder="Date de début" class="form-control" name="datedebut" id="datedebut" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Fin de contrat: </label>
                                        <input type="date" placeholder="Date de fin" class="form-control" name="datefin" id="datefin" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Date: <span class="obligatoire">*</span></label>
                                        <input type="date" placeholder="Date" class="form-control" name="date" id="date" value="{{ $date ?? '' }}">
                                    </div>
                                    <div class="form-group">
                                        <label for="repeat_type" class="control-label">Recurrence: <span class="obligatoire">*</span></label>
                                        <div class="radio-inline">
                                            <label>
                                                <input type="radio" id="repeat_type_onshot" name="repeat_type" value="oneshot" checked>
                                                Ponctuelle
                                            </label>
                                        </div>
                                        <div class="radio-inline">
                                            <label>
                                                <input type="radio" id="repeat_type_weekly" name="repeat_type" value="weekly">
                                                Chaque semaine
                                            </label>
                                        </div>
                                        <div class="radio-inline">
                                            <label>
                                                <input type="radio" id="repeat_type_monthly" name="repeat_type" value="monthly">
                                                Chaque mois
                                            </label>
                                        </div>
                                    </div>

                                </div>

                                <!-- Section planning remains in its original place -->
                                <div class="col-md-4 form-section hidden" id="div2" >
                                    <h4 class="form-section-title">Section planning</h4>

                                    <div class="form-group">
                                    <label class="control-label">Contrat: </label>
                                    <select class="form-control select2" name="contrat_id" id="contrat_id" onchange="populateContractDates(this.value)">
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Début de contrat: </label>
                                    <input type="date" placeholder="Date de début" class="form-control" name="datedebut" id="datedebut" disabled>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Fin de contrat: </label>
                                    <input type="date" placeholder="Date de fin" class="form-control" name="datefin" id="datefin" disabled>
                                </div>
                                    <div class="form-group">
                                        <label for="repeat_type" class="control-label">Recurrence: <span class="obligatoire">*</span></label>
                                        <div class="radio-inline">
                                            <label>
                                                <input type="radio" id="repeat_type_onshot" name="repeat_type" value="oneshot" checked>
                                                Ponctuelle
                                            </label>
                                        </div>
                                        <div class="radio-inline">
                                            <label>
                                                <input type="radio" id="repeat_type_weekly" name="repeat_type" value="weekly">
                                                Chaque semaine
                                            </label>
                                        </div>
                                        <div class="radio-inline">
                                            <label>
                                                <input type="radio" id="repeat_type_monthly" name="repeat_type" value="monthly">
                                                Chaque mois
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Description section remains unchanged -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label">Description:</label>
                                        <textarea placeholder="Description" class="form-control" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Form Layout Row -->
@endsection




@section('scripts')
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.5.1/sweetalert2.all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script>
        $(document).ready(function() {

            $('#contrat_id').select2({
                placeholder: 'Selectionner un contrat',
                theme: "classic",
                disabled: false
            });

            $('#intervenant_ids').select2({
                placeholder: 'Selectionner un ou plusieurs intervenants',
                theme: "classic"
            });
            $('#entreprise_id').select2({
                placeholder: 'Selectionner une entreprise',
                theme: "classic"
            });
            $('#client_id').select2({
                placeholder: 'Selectionner un client',
                theme: "classic"
            });

            $('input[name="repeat_type"]').change(function() {
                if ($(this).val() === 'recurrence') {
                    $('#recurrence-options').show();
                } else {
                    $('#recurrence-options').hide();
                }
            });



            $('input[name="address"]').prop('disabled', false);
            //error_message
            function error_message(messages, input) {
                return $("<span class='text-danger erreur' style='float:left;font-size:13px' >" + messages +
                        "</span>")
                    .insertAfter(input);
            }
            //test_number
            function test_number(number) {

                if (!isNaN(number)) {
                    return true
                } else {
                    return false
                }
            }


            $('#intervenant_id').change(function() {
            var intervenantId = $(this).val();

            if (intervenantId) {
            $.ajax({
                url: '/get-intervenant-color/' + intervenantId,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    // Check if response.color is valid
                    if(/^#[0-9A-F]{6}$/i.test(response.color)) {
                        $('#color').val(response.color);
                    } else {
                        console.warn('Invalid color format:', response.color);
                        $('#color').val('#ff0000'); // Fallback color
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    console.error('Status:', status);
                    console.error('Response Text:', xhr.responseText);
                }
            });
            } else {
            $('#color').val('#ff0000'); // Fallback color if no intervenant selected
            }})



            });
            function toggleDivs() {
            var selectedValue = document.getElementById("divSelector").value;
            document.getElementById("div1").classList.add("hidden");
            document.getElementById("div2").classList.add("hidden");

            if (selectedValue === "div1") {
                document.getElementById("div1").classList.remove("hidden");
            } else if (selectedValue === "div2") {
                document.getElementById("div2").classList.remove("hidden");
        }
}

            function saveintervention() {
            $('.erreur').empty();
            var obligatoire =
                "<p class='text-danger erreur' style='float:left;font-size:13px' >Ce champ est obligatoire</p>"

            var number =
                "<p class='text-danger erreur' style='float:left;font-size:13px' >Ce champ doit etre un telephone</p>"

            var date =
                "<p class='text-danger erreur' style='float:left;font-size:13px' >Ce champ doit etre une date</p>"

            // var intervenant = $("input[name='intervenant']").val();
            var intervenant_ids = $("#intervenant_ids").val(); // Corrected from intervenant_id to intervenant_ids
            console.log('intervenant_ids', intervenant_ids);
            var color = $("#color").val();
            var date = $("input[name='date']").val();
            var dateP = $("input[name='dateP']").val();
            var description = $("textarea[name='description']").val();
            var client_id = $("#client_id").val();
            var entreprise_id = $("#entreprise_id").val();
            var datedebut = $("#datedebut").val();
            var datefin = $("#datefin").val();
            var datedebutP = $("input[name='datedebutP']").val();
            var datefinP = $("input[name='datefinP']").val();
            var repeat_type = $("input[name='repeat_type']:checked").val();
            var address = $("input[name='address']").val();
            var form = new FormData();


            form.append('client_id', client_id);
            form.append('repeat_type', repeat_type);

            if (intervenant_ids) {
            intervenant_ids.forEach(function(id) {
                form.append('intervenant_ids[]', id); // Correctly append each intervenant ID
            });
            }

            console.log('intervenant_ids formData', form.getAll('intervenant_ids[]'));
            // form.append('intervenant', intervenant);
            form.append('entreprise_id', entreprise_id);
            form.append('description', description);


            var selectedValue = document.getElementById("divSelector").value;

            if (selectedValue === "div1") { // Contrat is selected

                form.append('datedebut', datedebut); // Append contrat date
                form.append('datefin', datefin);
                form.append('date', date);
            } else if (selectedValue === "div2") { // Planning is selected

                form.append('datedebut', datedebutP); // Append planning date
                form.append('datefin', datefinP);
                form.append('date', dateP);
            }


            form.append('color', color);
            form.append('address', address);

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });

            jQuery.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('input[name="_token"]').val()
                },
                url: "{{ url('/storeintervention') }}",
                method: 'post',
                data: form,
                cache: false,
                contentType: false,
                processData: false,
                success: function(result) {
                    console.log(result)
                    if (result.error) {
                        Swal.fire({
                            position: 'top-center',
                            icon: 'error',
                            title: 'Un erreur est survenu',
                            showConfirmButton: true,
                            timer: 3000
                        })
                        if (result.error.intervenant_id) {
                            error_message(result.error.intervenant[0],
                                "input[name='intervenant_id']")
                        }
                        if (result.error.color) {
                            error_message(result.error.color[0], "input[name='color']")
                        }
                        if (result.error.date) {
                            error_message(result.error.date[0], "input[name='date']")
                        }
                        if (result.error.datedebut) {
                            error_message(result.error.date[0], "input[name='datedebut']")
                        }
                        if (result.error.datefin) {
                            error_message(result.error.date[0], "input[name='datefin']")
                        }
                        if (result.error.repeat_type) {
                            error_message(result.error.date[0], "select[name='repeat_type']")
                        }
                        if (result.error.client_id) {
                            error_message(result.error.entreprise_id[0], "#client_id")
                        }
                        if (result.error.entreprise_id) {
                            error_message(result.error.entreprise_id[0], "#entreprise_id")
                        }

                    } else if (result.success) {

                        Swal.fire({
                            position: 'top-center',
                            icon: 'success',
                            title: 'Intervention ajouté avecc succéss',
                            showConfirmButton: false,
                            timer: 1000
                        })

                        setTimeout(function() {
                            window.location.href = "{{ url('interventions') }}";
                        }, 1000);
                        console.log(result.success_id)
                    }
                }
            });
        }

       function populateContractSelect(clientId) {
        $.ajax({
            url: '/get-contracts/' + clientId,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                var $contractSelect = $('#contrat_id');
                $contractSelect.empty();
                $contractSelect.append('<option value="">Select a contract</option>');
                $.each(response.contracts, function(index, contract) {
                    $contractSelect.append('<option value="' + contract.id + '">' + contract.numero + '</option>');
                });
                $contractSelect.trigger('change');
            },
            error: function(xhr, status, error) {
                console.error('Error fetching contracts:', error);
            }
        });
    }


       function populateContractDates(contractId) {
        $.ajax({
            url: '/get-contract-dates/' + contractId,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response) {
                    $('#datedebut').val(response.start_date).prop('disabled', false);
                    $('#datefin').val(response.end_date).prop('disabled', false);
                } else {
                    $('#datedebut').val('').prop('disabled', true);
                    $('#datefin').val('').prop('disabled', true);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching contract dates:', error);
            }
        });
    }

    </script>
@endsection