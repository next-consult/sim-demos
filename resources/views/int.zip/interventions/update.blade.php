@extends('layouts.newapp')

@section('styles')
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
@endsection

@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">

<!-- Breadcromb Row Start -->
<div class="row">
    <div class="col-md-12">
        <div class="breadcromb-area">
            <div class="row">
                <div class="col-md-7">
                    <div class="seipkon-breadcromb-left">
                        <h3>Modifier l'intervention</h3>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="btn-group" role="group" aria-label="Basic example" id="btn_group">
                        <button type="button" class="btn btn-info" onclick="updateIntervention()">
                            <i class="fa fa-check"></i> Enregistrer l'intervention
                        </button>
                        <a href="{{ route('interventions.index') }}">
                            <button type="button" class="btn btn-warning btn_retour" style="margin-left: 120px;">
                                <i class="fa-solid fa-backward"></i> Retour
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcromb Row -->

<!-- Form Layout Row Start -->
<div class="row">
    <div class="col-md-12">
        <div class="page-box">
            <div class="form-example">
                <div class="form-wrap top-label-exapmple form-layout-page">
                    <form id="updateInterventionForm">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="id" value="{{ $intervention->id }}">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Date: <span class="obligatoire">*</span></label>
                                    <input type="date" placeholder="Date" class="form-control" name="date" id="date"
                                        value="{{ old('date', $intervention->date) }}">
                                    <span class="text-danger" id="error_date"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Intervenant: <span class="obligatoire">*</span></label>
                                    <select class="form-control select2" name="intervenant_id" id="intervenant_id">
                                        <option value="">Sélectionner un intervenant</option>
                                        @foreach ($intervenants as $intervenant)
                                            <option value="{{ $intervenant->id }}"
                                                {{ $intervenant->id == old('intervenant_id', $intervention->intervenant_id) ? 'selected' : '' }}>
                                                {{ $intervenant->name }} 
                                            </option>
                                        @endforeach
                                    </select>
                                    <span class="text-danger" id="error_intervenant_id"></span>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                         


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Adresse:</label>
                                    <input type="text" placeholder="Adresse" class="form-control" name="address" id="address"
                                        value="{{ old('address', $intervention->address) }}" >
                                </div>
                            </div>
							 <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Client: <span class="obligatoire">*</span></label>
            <select class="form-control select2" name="client_id" id="client_id">
                <option value="">Sélectionner un client</option>
                @foreach ($clients as $client)
                    <option value="{{ $client->id }}"
                        {{ $client->id == old('client_id', $intervention->client_id) ? 'selected' : '' }}>
                        {{ $client->nom }} 
                    </option>
                @endforeach
            </select>
            <span class="text-danger" id="error_client_id"></span>
        </div>
    </div>
                        </div>

                        <!-- Add Client and Entreprise Information -->
                       <div class="row">
   
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label">Entreprise: <span class="obligatoire">*</span></label>
            <select class="form-control select2" name="entreprise_id" id="entreprise_id">
                <option value="">Sélectionner une entreprise</option>
                @foreach ($entreprises as $entreprise)
                    <option value="{{ $entreprise->id }}"
                        {{ $entreprise->id == old('entreprise_id', $intervention->entreprise_id) ? 'selected' : '' }}>
                        {{ $entreprise->nom }} 
                    </option>
                @endforeach
            </select>
            <span class="text-danger" id="error_entreprise_id"></span>
        </div>
    </div>
						   <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Description:</label>
                                    <textarea placeholder="Description" class="form-control" name="description" id="description">{{ old('description', $intervention->description) }}</textarea>
                                    <span class="text-danger" id="error_description"></span>
                                </div>
                            </div>
</div>



                        <div class="row">
                            
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Form Layout Row -->
@endsection

@section('scripts')
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.5.1/sweetalert2.all.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#intervenant_id').select2({
                placeholder: 'Sélectionner un intervenant',
                theme: "classic"
            });
        });

        function updateIntervention() {
            $('.text-danger').empty();
            $('.form-control').removeClass('is-invalid');

            var formData = $('#updateInterventionForm').serialize();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "{{ route('interventions.update', $intervention->id) }}",
                method: 'PUT',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'Success',
                            text: response.success,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(() => {
                            window.location.href = "{{ route('interventions.index') }}"; // Redirect to index page
                        });
                    }
                },
                error: function(xhr) {
                    console.log(xhr.responseJSON); // Log the entire response
                    var errors = xhr.responseJSON.error || xhr.responseJSON.errors;
                    if (errors) {
                        for (var field in errors) {
                            $('#' + field).addClass('is-invalid');
                            $('#error_' + field).text(errors[field][0]);
                        }
                    }
                }
            });
        }
    </script>
@endsection
